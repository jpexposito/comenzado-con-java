package es.ejemplos.jpexposito;

public class Fruta {

   String color;
   int peso;
   
}
