package es.ejemplos.jpexposito;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class GestionLinkedListTest {
    GestionLinkedList gestionLinkedList;

    @BeforeEach
    public void setUp() {
        if (gestionLinkedList == null) {
            gestionLinkedList = null;
        }
    }


    @Test
    public void primerTest() {
        assertTrue( true );
    }
}
